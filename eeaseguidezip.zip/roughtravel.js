
console.log("karthik")
document.getElementById('registrationForm').addEventListener('register', function(event) {
    event.preventDefault();
    
    const Name = document.getElementById('name').value;
    const PhoneNumber = document.getElementById('phoneNumber').value;
    const email = document.getElementById('email').value;
    const numberOfpeople = document.getElementById('nuberOfpeople').value;
    const location = document.getElementById('location').value;
    
    // alert(`Thank you, ${name}! Your trip to ${location} for ${numberOfPeople} has been booked. A confirmation email has been sent to ${email}. please reach out our contact number for payment`);
    
    // Here you would typically send the form data to a server
    // For example, using fetch API:
    // fetch('/api/book', {
    //     method: 'POST',
    //     headers: {
    //         'Content-Type': 'application/json'
    //     },
    //     body: JSON.stringify({ destination, date, name, email })
    // }).then(response => response.json())
    // .then(data => {
    //     // Handle response data
    // });
});
